/* Add protocol helper include file here */
#if defined(CONFIG_IP_NF_PPTP) || defined(CONFIG_IP_NF_PPTP_MODULE)
#include <linux/netfilter_ipv4/ip_conntrack_pptp.h>
#ifdef CONFIG_IP_NF_NAT_NEEDED
#include <linux/netfilter_ipv4/ip_nat_pptp.h>
#endif
#endif

